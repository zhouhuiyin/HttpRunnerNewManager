# NOTICE:
# This file should not be deleted, or ImportError will be raised in Python 2.7 when importing extension
